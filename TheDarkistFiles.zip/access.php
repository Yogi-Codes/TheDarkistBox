<?php

// Check if the form has been submitted
function escapeSpecialCharacters($input) {


  return preg_replace('/[@#$%^&*():":>]/', '\\\$0', $input);

}













if (isset($_POST['submit'])) {

  // Get the text from the form field

  $text = $_POST['text'];
  
    $text1= escapeSpecialCharacters($text);

  // Open the file for writing

  $file = fopen('access.log', 'a');



  // Write the text to the file

  fwrite($file, $text1 . "\n");



  // Close the file

  fclose($file);

}



?>



<!-- Form with text input and submit button -->

<form method="post">

  <label for="text">Enter your wish:</label><br>

  <input type="text" id="text" name="text"><br>

  <input type="submit" value="Submit" name="submit">

</form>


